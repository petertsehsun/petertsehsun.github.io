Tse-Hsun Chen
Stephen W. Thomas
Hadi Hemmati
Meiyappan Nagappan
Ahmed E. Hassan

156 Barrie Street
School of Computing, Queen's University
Kingston, ON, Canada, K7L 3N6
1.613.453.6162 phone
1.613.533.6513 fax

The files contain the name and full path of the files that we randomly
sampled to verify the accuracy of our heuristic for finding test files.

For example, eclipse_source.txt contains 50 files that are identified
as source code file according to our heuristics. eclipse_test.txt contains
50 files that are identified as test files according to our heuristic.

files_classified_incorrectly.txt contains the information about which
files are classified incorrectly, according to our manual verification.


